public class Students {

    public static void display() {

	System.out.println("By writing our names here, we declare that we are the authors of the code submitted in this assignment");
	System.out.println("============================================");
	System.out.println("*              Alae , Boufarrachene         ");
	System.out.println("*                    300188539              ");
	System.out.println("============================================");
    }

}