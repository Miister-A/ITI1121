
				s.display();