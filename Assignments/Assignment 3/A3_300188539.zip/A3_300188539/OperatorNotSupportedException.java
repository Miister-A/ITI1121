/*******************************/
/*Student number: 300188539
/*Student full name: Alae Boufarrachene
/*******************************/

public class OperatorNotSupportedException extends Exception {
    public OperatorNotSupportedException(String message) {
        super(message);
    }
}
