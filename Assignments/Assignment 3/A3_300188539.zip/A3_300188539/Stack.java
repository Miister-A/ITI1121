/*******************************/
/*Student number: 300188539
/*Student full name: Alae Boufarrachene
/*******************************/

public interface Stack<E> {
    boolean isEmpty();
    E peek();
    E pop();
    void push( E element);
}
