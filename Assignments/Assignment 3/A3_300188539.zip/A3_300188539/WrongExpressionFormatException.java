/*******************************/
/*Student number: 300188539
/*Student full name: Alae Boufarrachene
/*******************************/

public class WrongExpressionFormatException extends Exception {
    public WrongExpressionFormatException(String message) {
        super(message);
    }
}
