/*******************************/
/*Students numbers: 
/*Students full names: 
/*******************************/

import java.util.Scanner;

public class A3Q1{
	public static void main(String[] args){

		int output; // output of the expression evaluation
		//your code here
		
 
}