/*******************************/
/*Students numbers: 
/*Students full names: 
/*******************************/

import java.util.Scanner;

public class PostFixHandler{
	
  public int processExpression(String postFixExp)
  {
    LinkedStack<Integer> stack = new LinkedStack<Integer>();  
	//your code here

  }
}