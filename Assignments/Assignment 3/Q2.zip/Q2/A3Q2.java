/*******************************/
/*Students numbers: 
/*Students full names: 
/*******************************/
import java.util.Scanner;

public class A1Q2 {
	
	public static void main(String[] args) 
	{
		//your code here
		LinkedItems<Item> linkedItems = new LinkedItems<Item>();
		//your code here

	}
}

