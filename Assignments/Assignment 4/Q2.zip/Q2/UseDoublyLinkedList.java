/*******************************/
/*Students numbers: 
/*Students full names: 
/*******************************/
public class UseDoublyLinkedList {
  
  //develop your tests here 
  
  public static void main(String[] args) {

	 System.out.println("-------------------------------------");
	 System.out.println("* Student name:                     *");
	 System.out.println("* Student number:                   *");
	 System.out.println("-------------------------------------");
	 System.out.println("* Student name:                     *");
	 System.out.println("* Student number:                   *");
	 System.out.println("-------------------------------------");
	 System.out.println();
    
	// call your tests here
 
  }
}
