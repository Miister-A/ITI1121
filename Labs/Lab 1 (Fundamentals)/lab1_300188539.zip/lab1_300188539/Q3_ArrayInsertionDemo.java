public class Q3_ArrayInsertionDemo {

    public static int[] insertIntoArray(int[] beforeArray, int indexToInsert, int valueToInsert) {
        int[] newArray = beforeArray;
        newArray[indexToInsert] = valueToInsert;
        return newArray;
    }
    
    public static void main(String[] args) {

        int[] before = new int[]{1,5,4,7,9,6};
        System.out.println("----Array before insertion----");
        for (int i=0 ; i<before.length ; i++) {
            System.out.println("Element at index "+i+" : "+before[i]);
        }

        int[] after = new int[before.length];
        after = insertIntoArray(before, 5, 69);
        System.out.println("----Array after insertion----");
        for (int i=0 ; i<after.length ; i++) {
            System.out.println("Element at index "+i+" : "+after[i]);
        }
    }
}
