import java.util.Arrays;
import java.util.Collections;

public class Q3_ReverseSortDemo {
    
    public static void reverseSort(char[] values) {

        String[] tempCharToStringArray = new String[values.length]; //Creating an array to store converted characters into temporary strings
        
        for (int i=0 ; i<values.length ; i++) { //Converting each character into a string and storing them in an array of strings
            tempCharToStringArray[i] = Character.toString(values[i]);
        }

        Arrays.sort(tempCharToStringArray, Collections.reverseOrder()); //Sorts the array of strings in reverse order

        for (int i=0 ; i<values.length ; i++) { //Converting each string back into a character
            values[i] = tempCharToStringArray[i].charAt(0);
        }
    }

    public static void main(String[] args) {

        char[] unorderedLetters;
        unorderedLetters = new char[]{'b', 'a', 'z', 'a', 'u'};

        reverseSort(unorderedLetters);

        for (int i = 0 ; i < unorderedLetters.length; i++ )
        System.out.print(unorderedLetters[i]);
    }
}
