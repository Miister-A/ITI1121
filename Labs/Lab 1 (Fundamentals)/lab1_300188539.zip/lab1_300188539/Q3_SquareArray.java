public class Q3_SquareArray {

    public static int[] createArray(int size) {
        
        int[] createdArray = new int[size+1];

        for (int i=0 ; i<createdArray.length ; i++) {
            createdArray[i] = i*i;
            System.out.println("The square of "+i+" is : "+i*i);
        } 

        return createdArray;
    }

    public static void main(String[] args) { 
        createArray(12);
    }
}