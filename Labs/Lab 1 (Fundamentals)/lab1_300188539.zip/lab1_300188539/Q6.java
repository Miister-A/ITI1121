import java.util.Scanner;

public class Q6 {
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		double[] notes = new double[10];
		System.out.print("Input ten grades: ");
		for (int i = 0; i < notes.length; i++) notes[i] = input.nextDouble();
		System.out.println("Average: " + calculateAverage(notes));
		System.out.println("Median: " + calculateMedian(notes));
		System.out.println("Failed: " + calculateNumberFailed(notes));
		System.out.println("Passed: " + calculateNumberPassed(notes));
	}
	
	public static double calculateAverage(double[] notes) {
		
		double total = 0.0;
		for (int i = 0; i < notes.length; i++) total += notes[i];
		return total / notes.length;
	}
	
	public static double calculateMedian(double[] notes) {
		
		if (notes.length == 1) return notes[0];
		sort(notes); // assuming we're still not allowed to use arrays.sort
		if (notes.length % 2 == 0) return (notes[notes.length / 2] + notes[notes.length / 2 - 1]) / 2.0;
		else return notes[notes.length / 2];
	}
	
	public static int calculateNumberFailed(double[] notes) {
		
		int failures = 0;
		for (int i = 0; i < notes.length; i++) if (notes[i] < 50.0) failures++;
		return failures;
	}
	
	public static int calculateNumberPassed(double[] notes) {
		
		return notes.length - calculateNumberFailed(notes);
	}
	
	private static void sort(double[] values) {
		
		double swap;
		int progress = 0;
		for (int i = 1; progress < values.length; i = (i + 1) % (values.length)) {
			if (i == 0) i++;
			if (values[i - 1] > values[i]) {
				swap = values[i];
				values[i] = values[i - 1];
				values[i - 1] = swap;
				progress = 0;
			} else progress++;
		}
	}
}
