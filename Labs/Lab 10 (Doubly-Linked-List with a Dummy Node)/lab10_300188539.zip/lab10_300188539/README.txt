➥Name : Alae Boufarrachene
➥Program : Computer Engineering
➥Student number : 300188539
➥Course : ITI1121-Z
➥Lab number : #10
➥Academic year : 2020-2021
➥Archive description : This archive contains the 3 files of lab 10, that is, this file (README.txt), plus OrderedStructure.java, OrderedList.java.