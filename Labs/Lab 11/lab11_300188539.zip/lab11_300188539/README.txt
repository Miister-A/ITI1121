➥Name : Alae Boufarrachene
➥Program : Computer Engineering
➥Student number : 300188539
➥Course : ITI1121-Z
➥Lab number : #11
➥Academic year : 2020-2021
➥Archive description : This archive contains the 4 files of lab 11, that is, this file (README.txt), plus Iterator.java, BitList.java, Iterative.java.