➥Name : Alae Boufarrachene
➥Program : Computer Engineering
➥Student number : 300188539
➥Course : ITI1121-Z
➥Lab number : #2
➥Academic year : 2020-2021
➥Archive description : This archive contains the 3 files of the lab 2, that is, this file (README.txt), plus the files Combination.java and DoorLock.java