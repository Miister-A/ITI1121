➥Name : Alae Boufarrachene
➥Program : Computer Engineering
➥Student number : 300188539
➥Course : ITI1121-Z
➥Lab number : #3
➥Academic year : 2020-2021
➥Archive description : This archive contains the 3 files of the lab 3, that is, this file (README.txt), plus the files Utils.java and Rational.java.