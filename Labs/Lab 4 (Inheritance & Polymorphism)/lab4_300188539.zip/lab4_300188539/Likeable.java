public interface Likeable { //Interface of two declared abstract methods that are implemented in other classes
	public abstract void like();
	public abstract int getLikes();
}
