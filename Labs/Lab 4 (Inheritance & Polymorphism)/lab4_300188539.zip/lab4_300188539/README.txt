➥Name : Alae Boufarrachene
➥Program : Computer Engineering
➥Student number : 300188539
➥Course : ITI1121-Z
➥Lab number : #4
➥Academic year : 2020-2021
➥Archive description : This archive contains the 6 files of the lab 4, that is, this file (README.txt), plus the files Likeable.java, Post.java, TextPost.java, PhotoPost.java, NewsFeed.java.