➥Name : Alae Boufarrachene
➥Program : Computer Engineering
➥Student number : 300188539
➥Course : ITI1121-Z
➥Lab number : #5
➥Academic year : 2020-2021
➥Archive description : This archive contains the 8 files of lab 5, that is, this file (README.txt), plus Book.java, Library.java, BookComparator.java, Series.java, AbstractSeries.java, Arithmetic.java, Geometric.java.
