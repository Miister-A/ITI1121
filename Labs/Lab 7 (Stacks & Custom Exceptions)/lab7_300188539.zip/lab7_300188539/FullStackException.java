public class FullStackException extends RuntimeException {
}
