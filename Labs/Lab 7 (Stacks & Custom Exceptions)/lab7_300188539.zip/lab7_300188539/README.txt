➥Name : Alae Boufarrachene
➥Program : Computer Engineering
➥Student number : 300188539
➥Course : ITI1121-Z
➥Lab number : #7
➥Academic year : 2020-2021
➥Archive description : This archive contains the 7 files of lab 7
