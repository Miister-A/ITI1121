➥Name  Alae Boufarrachene
➥Program  Computer Engineering
➥Student number  300188539
➥Course  ITI1121-Z
➥Lab number  #8
➥Academic year  2020-2021
➥Archive description : This archive contains the 5 files of lab 8, that is, this file (README.txt), plus Queue.java, ArrayQueue.java, Customer.java, Cashier.java.